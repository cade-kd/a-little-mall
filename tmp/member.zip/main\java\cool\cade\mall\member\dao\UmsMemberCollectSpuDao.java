package cool.cade.mall.member.dao;

import cool.cade.mall.member.entity.UmsMemberCollectSpuEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 会员收藏的商品
 * 
 * @author ander
 * @email cade@cade.cool
 * @date 2022-04-15 18:30:53
 */
@Mapper
public interface UmsMemberCollectSpuDao extends BaseMapper<UmsMemberCollectSpuEntity> {
	
}
